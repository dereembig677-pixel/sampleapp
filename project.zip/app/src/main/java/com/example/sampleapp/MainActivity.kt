package com.example.sampleapp

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {

    private var count = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        count = savedInstanceState?.getInt("count") ?: 0

        val title = TextView(this).apply {
            text = "سلام! این اپ نمونه است"
            textSize = 24f
            gravity = Gravity.CENTER
        }

        val counter = TextView(this).apply {
            text = count.toString()
            textSize = 64f
            gravity = Gravity.CENTER
        }

        val addButton = Button(this).apply {
            text = "یکی اضافه کن"
            setOnClickListener {
                count++
                counter.text = count.toString()
            }
        }

        val resetButton = Button(this).apply {
            text = "صفر کن"
            setOnClickListener {
                count = 0
                counter.text = "0"
            }
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(48, 48, 48, 48)
            addView(title)
            addView(counter)
            addView(addButton)
            addView(resetButton)
        }

        setContentView(root)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("count", count)
    }
}
